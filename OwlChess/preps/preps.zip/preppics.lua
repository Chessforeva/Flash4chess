--
-- Reads bmp->raw file  24-bits=(B,G,R)
--
-- Prepares .as code of data

as3_file = "Pics.as";

print("Preparing " .. as3_file);
ou_file = assert(io.open(as3_file, "wb"));

TB = string.char(9);
CR = string.char(13) .. string.char(10);
CL = {};	-- colors list

transpcolors = {"669966", "008000", "ffffff"};

i = 1;
while(i<= table.getn(transpcolors)) do
  CL[i] = transpcolors[i];
  i = i + 1;
end


-- reads data

PC = {};	-- colors of pixels
k = 0;

s = "";
u = "";
 
RdCnt = 0;

-- =======
-- open a bmp file, read pixels

function read_in_file()
 
 PC = {};

-- reading rows of pixels from left bottom corner up
--

 local in_file = assert(io.open(filename, "rb"));

 in_file:read(54);	-- skip header

 local c = 0;
 local o = 0;
 
 while (1==1) do

    local buf = in_file:read(3);
    if not buf then break end;
    
    R = string.byte(buf,1);
    G = string.byte(buf,2);
    B = string.byte(buf,3);
    
    local b = "";
    b = b .. string.format("%2x", B);    
    b = b .. string.format("%2x", G);
    b = b .. string.format("%2x", R);
    b = string.gsub(b," ","0");
    
    c = c+1;
    PC[c] = b;
    o = o + 1;
    if(o==WW) then
	buf = in_file:read( WW % 4 );
	o = 0;
    end
    
 end
 
 in_file:close();

end

-- =======

-- is color transparent?
function isTranspCol(color)

local i=1;
while(i<= table.getn(transpcolors)) do
  if(transpcolors[i]==color) then
	return true;
  end
  i = i + 1;
end
return false;

end


-- =======
-- read pixels

function Rd(cnm,x,y,x2,y2,transp)

 local w,h,dx,dy,v,j,k,fo,r,buf,P,m;
 
 -- for pieces,1 pixel for cursor
 if(RdCnt<12) then
  x = x-1;
  y = y-1;
  x2 = x2+1;
  y2 = y2+1;
 end

 w = 1+x2-x;
 h = 1+y2-y;
 dx = 0; dy = 0;
 if(RdCnt<12) then
  dx = ((x-23) % 36);
  dy = ((y-23) % 36);
 end

 r = "public const " .. cnm .. ":Array = [ " ..
	dx .. ", " .. dy .. ", " .. w .. ", " .. h .. ", " .. CR;
 
 
 j = 0;
 while (j<h) do

  j = j + 1;
  P = (WW * (HH-(y+j))) + x;
  
  r = r .. '"';

  v = 0;
  while (v<w) do
    v = v + 1;
    
    P = P + 1;
    buf = PC[P];
	
    if (transp and isTranspCol(buf)) then
	k = 0
    else
	
    	k = 1; fo = 0;
	while (k<=table.getn(CL)) do
	
	 if( CL[k]== buf ) then
	    fo = 1;
	    break;
	 end
	 k = k + 1;
	end
	if (fo==0) then
	 CL[k] = buf;
	end
    end

    if (k>=26) then
	m = 65 + (k-26);
    else
	m = 97 + k;
    end
    r = r .. string.char(m);
    
  end
  r = r .. '",' .. CR;
 end

r = string.sub(r,1, string.len(r)-3) .. CR .. "];" .. CR .. CR;

if( string.len(list)>0 ) then
  list = list .. ",";
end
list = list .. CR .. "/*" ..  RdCnt .. "*/" .. TB .. cnm;

RdCnt = RdCnt + 1;

return r;

end
-- =======

list = "";

filename = "boardparts.bmp";
HH = 234;	-- height
WW = 154;	-- width

read_in_file();

u =u .. Rd("white_king",97,132,128,164, true);
u =u .. Rd("white_queen",96,96,128,128, true);
u =u .. Rd("white_rook",28,139,53,164, true);
u =u .. Rd("white_bishop",67,100,87,127, true);
u =u .. Rd("white_knight",63,137,89,164, true);
u =u .. Rd("white_pawn",32,101,48,128, true);

u =u .. Rd("black_king",97,24,128,56, true);
u =u .. Rd("black_queen",96,60,128,92, true);
u =u .. Rd("black_rook",28,31,53,56, true);
u =u .. Rd("black_bishop",67,64,87,91, true);
u =u .. Rd("black_knight",63,29,89,56, true);
u =u .. Rd("black_pawn",32,65,48,92, true);

X = 7; Y = 210;
T = 97;
while T<(97+8) do
  u =u .. Rd("lab_" .. string.char(T),X,Y,X+11,Y+16, false);
  T = T + 1;
  X = X + 16;
end

X = 7; Y = 169;
T = 49;
while T<(49+8) do
  u =u .. Rd("lab_" .. string.char(T),X,Y,X+11,Y+18, false);
  T = T + 1;
  Y = Y - 19;
end

-- board parts

u =u .. Rd("BG0",4,4,7,7, false);

u =u .. Rd("LU0",0,0,3,3, false);
u =u .. Rd("RU0",150,0,153,3, false);
u =u .. Rd("U0",7,0,10,3, false);
u =u .. Rd("L0",0,4,3,7, false);
u =u .. Rd("R0",150,4,153,7, false);
u =u .. Rd("LD0",0,230,3,233, false);
u =u .. Rd("RD0",150,230,153,233, false);
u =u .. Rd("D0",7,230,10,233, false);

u =u .. Rd("LU1",19,19,22,22, false);
u =u .. Rd("RU1",131,19,134,22, false);
u =u .. Rd("U1",23,19,26,22, false);
u =u .. Rd("L1",19,23,22,26, false);
u =u .. Rd("R1",131,23,134,26, false);
u =u .. Rd("LD1",19,203,22,206, false);
u =u .. Rd("RD1",131,203,134,206, false);
u =u .. Rd("D1",23,203,27,206, false);

u =u .. Rd("Lite_Square",95,167,98,170, false);
u =u .. Rd("Dark_Square",59,167,62,170, false);

-- buttons and other

filename = "scrparts.bmp";
HH = 280;	-- height
WW = 68;	-- width

read_in_file("scrparts4.bmp");

u =u .. Rd("Scale",8,6,35,13, true);
u =u .. Rd("Scalex1",6,17,25,32, false);
u =u .. Rd("Scalex2",30,17,49,32, false);

u =u .. Rd("newgame",2,43,63,60, false);
u =u .. Rd("takeback",2,63,63,80, false);
u =u .. Rd("selfgame",2,83,63,100, false);
u =u .. Rd("sfredlt",57,103,61,107, false);

u =u .. Rd("AI",3,117,13,124, true);
u =u .. Rd("brain0",20,116,44,131, false);
u =u .. Rd("brain1",20,141,44,156, false);

u =u .. Rd("depth",4,206,37,215, true);
u =u .. Rd("timesec",2,221,41,230, true);

u =u .. Rd("plus",4,237,17,250, false);
u =u .. Rd("minus",19,237,32,250, false);



z = "public const List:Array = [" .. list .. CR .. TB .. "];"


s = "package" .. CR .. "{" .. CR .. TB .. "public class Pics" .. CR .. TB .. "{" .. CR;
s = s .. CR .. TB .. "public const ColPalette:Array = [" .. CR  .. TB .. TB;

k = 1;
while (k<=table.getn(CL)) do

    buf = CL[k];
    
    if(k>1) then
	s = s .. ", ";
	if(k % 5 == 1) then
	    s = s .. CR .. TB .. TB;
	end
    end
    
    s = s .. '0x' .. buf;
    
    k = k + 1;

end
s = s .. " ];" .. CR .. CR;

print( k .. " colors" );

s = s .. CR .. TB .. "/*" .. CR .. TB .. " datas of pictures:" .. CR ..
	TB .. " Skip right dx, Skip down dy, Width, Height, " .. CR ..
	TB .. " arrays of color bytes " ..
	"('a'-transp., or ColPalette# 'b'=0,'c'=1,...,'z','A'=26,...)" .. CR ..
	TB .. "*/" .. CR .. CR;

s = s .. u .. CR .. TB .. z .. CR .. CR;

s = s .. TB .. "}" .. CR .. "}" .. CR;

ou_file:write(s);


ou_file:close();

print("Ok");






