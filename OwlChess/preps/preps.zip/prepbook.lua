--
-- Reads binary book file
--
-- Prepares .as code of data

as3_file = "OwlBook.as";

print("Preparing " .. as3_file);
ou_file = assert(io.open(as3_file, "wb"));

TB = string.char(9);
CR = string.char(13) .. string.char(10);

s = "package" .. CR .. "{" .. CR .. TB .. "public class OwlBook" .. CR .. TB .. "{" .. CR;
s = s .. CR .. TB .. "public var Openings:Array = [" .. CR;

local in_file = assert(io.open("OPENING.LIB", "rb"));

B = {};

n = 0;
while (1==1) do

    local buf = in_file:read(1);
    if not buf then break end;
    
    n = n + 1;
    B[n] = string.byte(buf,1);
end
in_file:close();

print( n .. " bytes scanned" );
tot = n;

while( B[n]==0 ) do
    n = n - 1;
end

j = 0;
while (j < n) do
    j = j + 1;
    
    s = s .. B[j] .. ",";
    if(j % 30==0) then
	s = s .. CR;
    end
end
    
s = string.sub(s,1, string.len(s)-1) .. CR .. "];" .. CR;
s = s .. CR .. TB .. "public const total:int = " .. tot .. ";" .. CR;
s = s .. TB .. "}" .. CR .. "}" .. CR;


ou_file:write(s);
ou_file:close();



print("Ok");